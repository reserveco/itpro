/* import Vue from 'vue'
import Quasar from 'quasar'

Vue.use(Quasar)
 */
