<template>
  <div class="container mx-auto px-4">
    <Navbar />
    <Nuxt />
  </div>
</template>

<style>
body {
  background: url('~/assets/img/subtlepatterns/brillant.png');
}
</style>
