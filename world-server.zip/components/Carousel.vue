<template>
  <div uk-slider="autoplay:true; autoplay-interval:3000;">
    <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-3@s uk-child-width-1-4@m uk-light">
      <li>
        <img src="https://getuikit.com/docs/images/slider1.jpg" alt="" />
      </li>
      <li>
        <img src="https://getuikit.com/docs/images/slider2.jpg" alt="" />
      </li>
      <li>
        <img src="https://getuikit.com/docs/images/slider3.jpg" alt="" />
      </li>
      <li>
        <img src="https://getuikit.com/docs/images/slider4.jpg" alt="" />
      </li>
      <li>
        <img src="https://getuikit.com/docs/images/slider5.jpg" alt="" />
      </li>
    </ul>
  </div>
</template>
