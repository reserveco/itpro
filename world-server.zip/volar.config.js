module.exports = {
  plugins: [require('volar-service-vetur').default()],
}
